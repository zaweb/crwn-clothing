export const selectCategoriesMap = (state) => state.categories.categoriesMap;
